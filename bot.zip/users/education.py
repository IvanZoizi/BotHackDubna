import datetime

from aiogram import Router, F, types
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, ReplyKeyboardRemove

from keyboards import *
from states import NewStates
from databases import DataBase

router = Router()


@router.message(F.data == 'education')
async def start_education(call: types.CallbackQuery):
    await call.message.delete()
    await call.message.answer("Выберете, что вы хотите сделать?", reply_markup=start_education_kb())


@router.message(F.data == 'school')
async def school(call: types.CallbackQuery, state: FSMContext):
    year = int(datetime.datetime.now().strftime("%Y"))
    await state.update_data(year_true=[year - 7, year - 6])
    await state.set_state(NewStates.name)
    await call.message.delete()
    await call.message.answer("Чтобы записать ребенка в школу для начала напишите ФИО ребенка")


@router.message(StateFilter(NewStates.name))
async def school_name(message: types.Message, state: FSMContext):
    surname, name, fatherhood = message.text.split()
    await state.update_data(name=name, surname=surname, fatherhood=fatherhood)
    await message.answer("Введите год рождения ребенка")
    await state.set_state(NewStates.year)


@router.message(StateFilter(NewStates.year))
async def school_year(message: types.Message, state: FSMContext, dbase: DataBase):
    data = await state.get_data()
    try:
        if int(message.text) not in data['year_true']:
            return await message.answer("Введите год рождения ребенка, возраст некорректный")
    except ValueError:
        return await message.answer("Введите год рождения ребенка, возраст некорректный")
    check = dbase.get_edicational_user(message.from_user.id, data['name'], data['surname'], data['fatherhood'])

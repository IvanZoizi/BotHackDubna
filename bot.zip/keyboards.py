from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram import types


def start_kb():
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text='Запись к врачу', callback_data='doctors'),
                types.InlineKeyboardButton(text="Образование", callback_data='education'))
    builder.row(types.InlineKeyboardButton(text='ЖКХ', callback_data='communal_services'),
                types.InlineKeyboardButton(text="Авто", callback_data='avto'))
    builder.row(types.InlineKeyboardButton(text='Связаться с ассистентом', callback_data='doctors'))
    return builder.as_markup()


def back_kb():
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text='Вернуться в меню', callback_data='start'))
    return builder.as_markup()


def start_education_kb():
    builder = InlineKeyboardBuilder()
    builder.row(types.InlineKeyboardButton(text='🏫 Запись в школу', callback_data='school'))
    builder.row(types.InlineKeyboardButton(text='🎓ВУЗ', callback_data='university'),
                types.InlineKeyboardButton(text="🧒Детский сад", callback_data='kindergarten'))
    builder.row(types.InlineKeyboardButton(text='👨‍💻Колледж', callback_data='school'))
    builder.row(types.InlineKeyboardButton(text='📝Прошлые записи', callback_data='past_education'))
    builder.row(types.InlineKeyboardButton(text='📍Ближайшие учебные заведения', callback_data='geo_education'))
    return builder.as_markup()


def start_doctors_kb():
    pass


def start_communal_services_kb():
    pass


def start_avto_kb():
    pass

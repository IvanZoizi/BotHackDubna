import asyncio

from aiogram import Bot, Dispatcher, types, F
from aiogram.filters import Command, StateFilter
from aiogram.fsm.context import FSMContext

from config import *
from keyboards import *
from databases import DataBase
from users import doctors, communal_services, education, avto
from states import StartState
from promts import *
from gpt import gpt_request

bot = Bot(token=token)
dp = Dispatcher()
dbase = DataBase('./db.sqlite')


@dp.message(Command("start"))
async def cmd_start(message: types.Message, state: FSMContext):
    await message.answer(
        "Привет, найду информацию и расскажу об услуге!",
        reply_markup=start_kb()
    )
    # await state.set_state(StartState.text_of_user)


@dp.message(F.text)
async def start_answer_user(message: types.Message, state: FSMContext):
    await state.clear()
    text = gpt_request(message.text, promt_start)
    print(text)
    if text == 'education':
        await message.answer("Выберете, что вы хотите сделать?", reply_markup=start_education_kb())
    elif text == 'doctors':
        await message.answer('...', reply_markup=start_doctors_kb())
    elif text == 'communal_services':
        await message.answer('...', reply_markup=start_communal_services_kb())
    elif text == 'avto':
        await message.answer('...', reply_markup=start_avto_kb())
    else:
        await message.answer("Возможно я не смогу вам помочь с данным вопросов, скоро к вам подключиться ассистент и поможет вам",
                             reply_markup=back_kb())


async def main():
    await bot.delete_webhook(drop_pending_updates=True)
    await dp.start_polling(bot, dbase=dbase)

    dp.include_routers(doctors.router)


if __name__ == "__main__":
    asyncio.run(main())